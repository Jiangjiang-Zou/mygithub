package ��½ҳ��;
import java.awt.GridLayout;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.*;

import javax.swing.*;
public class query {
	JFrame f = new JFrame("��ѯ����");
	selectall sa = new selectall();
	JLabel la = new JLabel("ѡ���ѯ��ʽ��");	
	JList<String> list = sa.each();
	 JPanel p1 = new JPanel();
	 JPanel p3 = new JPanel();
	 JButton q = new JButton("��ѯ");
	 final JComboBox<String> comboBox;
	 //��ѯ�ֶ������
	 JTextField jtf = new JTextField(10);
	 JLabel count = new JLabel("   �� �� ����"+sa.getcount());
	 //�������
	 JScrollPane p2 = new JScrollPane(list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	 public query() {
		 f.setSize(600, 600);
		 f.setLocationRelativeTo(null);
		 f.setDefaultCloseOperation(2);
		 f.setLayout(new GridLayout(2, 1));//����ʽ����
		 //��Ҫѡ��Ĳ�ѯ��ʽ
		 String[] listData = new String[]{"Ժϵ����","ְ��","ѧ��","�γ���","����"};
		 comboBox = new JComboBox<String>(listData);
		 final String str1 = new String("ְ��");
		 final String str2 = new String("ѧ��");
		 //������Ŀѡ��״̬�ı�ļ�����
		// comboBox.addItemListener(new ItemListener()
		 q.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
					 System.out.println("ѡ�У�"+comboBox.getSelectedIndex()+" = "+comboBox.getSelectedItem());
					 if(jtf.getText()!=""){
					 switch(comboBox.getSelectedIndex()) {
					 case 0: sa.co_name(jtf.getText());number(); break;
					 case 1: sa.zx(str1,jtf.getText());number(); break;
					 case 2: sa.zx(str2,jtf.getText());number(); break;
					 case 3: sa.course(jtf.getText());number(); break;
					 case 4: sa.tea_name(jtf.getText());number(); break;
					 default: break;
					}}}
			}); 
		 comboBox.setSelectedIndex(-1);
		 //comboBox.getSelectedIndex();
		 p1.add(la);
		 p1.add(comboBox);
		 p1.add(jtf);
		 p1.add(q);
		// p1.add(comboBox);
//		 p1.add(p3);
		 p1.add(count);
		 f.add(p1);
		// f.add(p3);
		 f.add(p2);
		 f.setVisible(true);
	 }
	 
	 //��ʾ������
	 public void number() {
		 count.setText(" �� �� ����"+sa.getcount());
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new query();
	}

}
