package ��½ҳ��;
import java.awt.GridLayout;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.*;

import javax.swing.*;
public class d_query {
	JFrame f = new JFrame("��ѯ����");
	d_selectall sa = new d_selectall();
	JLabel la;	
	JList<String> list = sa.returnList();
	//JList<String> list = sa.each();
	 JPanel p1 = new JPanel();
	// JPanel p3 = new JPanel();
	 JButton q = new JButton("��ѯ");
	 final JComboBox<String> comboBox;
	 public d_query() {
		 //��Ҫѡ��Ĳ�ѯ��ʽ
		 String[] listData = new String[]{"�γ�","����"};
		 comboBox = new JComboBox<String>(listData);
	 }
	 
	 //��ѯ�ֶ������
	 JTextField jtf = new JTextField(10);
	 //�������
	 JScrollPane p2 = new JScrollPane(list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	
	 //ѡ����ַ�ʽ����������ѯ
	 public  JComponent qspeak() {
		 JPanel jp = new JPanel((new GridLayout(1,2)));//����ʽ����
		 
		 
		// final String str1 = new String("ְ��");
		 //final String str2 = new String("ѧ��");
		 //������Ŀѡ��״̬�ı�ļ�����
		// comboBox.addItemListener(new ItemListener()
		 q.addActionListener(new ActionListener() {
			
//@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
					 System.out.println("ѡ�У�"+comboBox.getSelectedIndex()+" = "+comboBox.getSelectedItem());
					 if(jtf.getText()!=""){
					 switch(comboBox.getSelectedIndex()) {
					 case 0: sa.sel_speak1(jtf.getText());break;
					 case 1: sa.sel_speak2(jtf.getText());break;
					 default: break;
					}}}
			}); 
		 comboBox.setSelectedIndex(-1);
		 //comboBox.getSelectedIndex();
		 la = new JLabel("ѡ���ѯ��ʽ��");
		 p1.add(la);
		 p1.add(comboBox);
		 p1.add(jtf);
		 p1.add(q);
		// p1.add(comboBox);
//		 p1.add(p3);
		 jp.add(p1);
		// f.add(p3);
		 jp.add(p2);
		 return jp;
	 }
	 
	 //��ʾ������


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new d_query();
	}

}
