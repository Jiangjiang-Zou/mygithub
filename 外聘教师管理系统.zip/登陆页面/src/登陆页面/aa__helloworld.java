package ��½ҳ��;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class aa__helloworld {	

	JFrame f = new JFrame("��ѯ����");
	d_selectall sa = new d_selectall();
	JLabel la = new JLabel("ѡ���ѯ��ʽ��");	
	JList<String> list = sa.each();
	 JPanel p1 = new JPanel();
	 JPanel p3 = new JPanel();
	 JButton q = new JButton("��ѯ");
	 final JComboBox<String> comboBox;
	 public aa__helloworld(){
	 String[] listData = new String[]{"Ժϵ����","ְ��","ѧ��","�γ���","����","ȫ��"};
	 comboBox = new JComboBox<String>(listData);
	 }
	 comboBox.setSelectedIndex(-1);
	 //comboBox.getSelectedIndex();
	 p1.add(la);
	 p1.add(comboBox);
	 p1.add(jtf);
	 p1.add(q);
	// p1.add(comboBox);
//	 p1.add(p3);
	 p1.add(count);
	 jp.add(p1);
	// f.add(p3);
	 jp.add(p2);
	 return jp;
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			new aa__helloworld();
		}

	}