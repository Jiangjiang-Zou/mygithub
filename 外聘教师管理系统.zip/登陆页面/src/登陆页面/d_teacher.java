package ��½ҳ��;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.*;
public class d_teacher {
	
	
	public JComponent tea_myspeak(String name) {
		JPanel jp = new JPanel(new GridLayout(3,1));

		JLabel jlb1 = new JLabel("����γ�");		
		JLabel jlb2 = new JLabel("����");	
		JTextField jtf1 = new JTextField(10);
		JTextField jtf2 = new JTextField(10);
		JButton q = new JButton("����");	
		 JPanel p1 = new JPanel();
		 JPanel p2 = new JPanel();
		//p1.add(new JPanel());
		//p1.add(new JPanel());
		p1.add(jlb1);
		p2.add(jlb2);	
		p1.add(jtf1);		
		p2.add(jtf2);
		p2.add(q);
		jp.add(p1);
		jp.add(p2);
			
		//jp.add(p1);
		d_selectall sa = new d_selectall();
		JList<String> mycourse_list = sa.sel_speak4(name,jtf1.getText(),jtf2.getText());    //��ȡ����γ̺���Ҫ��������
		JScrollPane jsp1 = new JScrollPane(mycourse_list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		jp.add(jsp1);

		return jp;
		
	}
	public JComponent tea_course(String id) {
		JPanel jp = new JPanel(new GridLayout(2, 1));
		JLabel course_name = new JLabel("�γ�����");
		JTextField jtf = new JTextField(10);
		JButton add = new JButton("���ӿγ�");	
		JButton del = new JButton("ɾ���γ�");				

		JPanel p1 = new JPanel();
		p1.add(new JPanel());
		p1.add(new JPanel());
		p1.add(new JPanel());
		
		p1.add(course_name);
		p1.add(jtf);
		p1.add(add);
		p1.add(del);
			
		jp.add(p1);
		selectall sa = new selectall();
		selectall sa2 = new selectall();
		JList<String> mycourse_list = sa2.tea_course(id);//�ҵĿγ�
		JScrollPane jsp1 = new JScrollPane(mycourse_list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		

		JList<String> allcourse_list = sa.course_each();//ȫ���γ�
		JScrollPane jsp2 = new JScrollPane(allcourse_list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jp.add(jsp1);
		jp.add(jsp2);
		add.addActionListener(new ActionListener() {
        	 @Override
        	 public void actionPerformed(ActionEvent e) {
        		 sa2.tea_addcourse(id,jtf.getText());
        		 sa2.tea_course(id);//������ʾ�γ���Ϣ
        	 }
         });
		
		del.addActionListener(new ActionListener() {
       	 @Override
       	 public void actionPerformed(ActionEvent e) {
       		 sa2.tea_delcourse(id,jtf.getText());
       		 sa2.tea_course(id);//������ʾ�γ���Ϣ
       	 }
        });
		
		
		
		return jp;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
