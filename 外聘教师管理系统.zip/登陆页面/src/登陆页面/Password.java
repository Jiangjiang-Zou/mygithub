package ��½ҳ��;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.sql.*;

import java.awt.*;
public class Password {
			JPasswordField pastPassword = new JPasswordField(10);
			JPasswordField newPassword = new JPasswordField(10);
			JPasswordField confirmPassword = new JPasswordField(10);  
	public JComponent alterPassword(String id, int access) {
		JPanel jp = new JPanel(new GridLayout(8,1));
		JPanel p1 = new JPanel(new GridLayout(1,2));
		JPanel p2 = new JPanel(new GridLayout(1,2));
		JPanel p3 = new JPanel(new GridLayout(1,2));
		JPanel p4 = new JPanel(new GridLayout(1,2));
		JLabel JLpastPassword = new JLabel("�����룺");
		JLabel JLnewPassword = new JLabel("�����룺");
		JLabel JLconfirmPassword = new JLabel("ȷ�������룺");
		
		
		
		JButton submit = new JButton("�ύ");
		JButton resetting = new JButton("����");
		
		p1.add(JLpastPassword);
		p1.add(pastPassword);
		
		p2.add(JLnewPassword);
		p2.add(newPassword);
		
		p3.add(JLconfirmPassword);
		p3.add(confirmPassword);
		
		p4.add(submit);
		p4.add(resetting);
		
		jp.add(p1);
		jp.add(p2);
		jp.add(p3);
		jp.add(p4);
		submit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(newPassword.getText().equals(confirmPassword.getText()) != true) {
		               JOptionPane.showMessageDialog(null,"���벻һ�£�","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);  
				}
				else if(isRight(id,pastPassword.getText(),access) != true) {
		               JOptionPane.showMessageDialog(null,"�������","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);  
				}
				else {
					update(id,newPassword.getText(),access);
		              JOptionPane.showMessageDialog(null,"���ĳɹ���","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);  

				}
			}
		});
		
		resetting.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clear();
			}
		});
		
		return jp;
	}
	
	//��֤�����Ƿ���ȷ
	public boolean isRight(String id,String password, int access) {
		boolean isCorrect = false;
		selectall sa = new selectall();
		Connection conn = sa.con();
		String p = new String();
     	PreparedStatement pstmt = null;  	
   	 try{	        
	        // ִ�в�ѯ
	        System.out.println(" ʵ����Statement����...");
	        
	        //����ʦ��Ϣд�����ݿ�
	        String sql;
	        if(access == 0 ) {
		        sql = "SELECT * FROM ibm.tea_user where name = ?;";

	        }
	        else if(access == 1) {
	        	sql = "SELECT * FROM ibm.stu_user where name = ?;";
	        }
	        else {
	        	sql = "SELECT * FROM ibm.admin where name = ?;";
	        }
	        
	       pstmt = conn.prepareStatement(sql);
	       pstmt.setString(1, id);
	       ResultSet rs = pstmt.executeQuery();
	       
	        // չ����������ݿ�
	        while(rs.next()){
	            // ͨ���ֶμ���
	        	p = rs.getString("password");
	        	if(p.equals(password)) {
	        		isCorrect = true;
	        		break;
	        	}
	        }
	        
	         //��ɺ�ر�
	        rs.close();
	        pstmt.close();
	        conn.close();
	    }catch(SQLException se){
	        // ���� JDBC ����
	        se.printStackTrace();
	    }catch(Exception e){
	        // ���� Class.forName ����
	        e.printStackTrace();
	    }finally{
	        // �ر���Դ
	        try{
	            if(pstmt!=null) pstmt.close();
	        }catch(SQLException se2){
	        }// ʲô������
	        try{
	            if(conn!=null) conn.close();
	        }catch(SQLException se){ 
	            se.printStackTrace();
	        }
	    }
	    System.out.println("Goodbye!");
    	return isCorrect;
	}
	
	public void update(String id, String password,int access) {
		selectall sa = new selectall();
		Connection conn = sa.con();
     	PreparedStatement pstmt = null;
	 	
   	 try{	        
	        // ִ�в�ѯ
	        System.out.println(" ʵ����Statement����...");
	        
	        //����ʦ��Ϣд�����ݿ�
	        String sql;
	        if(access == 0) {
	        	sql = "update ibm.tea_user set password=? where name=?;";
	        }
	        else if(access == 1){
	        	sql = "update ibm.stu_user set password=? where name=?;";

	        }
	        else {
	        	sql = "update ibm.admin set password=? where name=?;";
	        }
	       pstmt = conn.prepareStatement(sql);
	       pstmt.setString(1, password);
	       pstmt.setString(2, id);
	       pstmt.executeUpdate();
	       
	        pstmt.close();
	        conn.close();
	    }catch(SQLException se){
	        // ���� JDBC ����
	        se.printStackTrace();
	    }catch(Exception e){
	        // ���� Class.forName ����
	        e.printStackTrace();
	    }finally{
	        // �ر���Դ
	        try{
	            if(pstmt!=null) pstmt.close();
	        }catch(SQLException se2){
	        }// ʲô������
	        try{
	            if(conn!=null) conn.close();
	        }catch(SQLException se){ 
	            se.printStackTrace();
	        }
	    }
	    System.out.println("Goodbye!");
	}
	
	public void clear() {
		String str = new String("");
		pastPassword.setText(str);
		newPassword.setText(str);
		confirmPassword.setText(str);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
