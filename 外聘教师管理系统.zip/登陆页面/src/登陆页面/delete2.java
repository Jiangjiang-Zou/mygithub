package ��½ҳ��;

import java.awt.GridLayout;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class delete2 {
		selectall sa = new selectall();
		selectall sa2 = new selectall();
		JList<String> list = sa2.each();//��Ž�ʦ�б�
		JList<String> course_list = sa.course_each();//��ſγ���Ϣ
		
	 JLabel tea_id = new JLabel("��ʦ��ţ�");
     JTextField Jtea_id = new JTextField(10);
     JLabel course_id = new JLabel("�γ̺ţ�");
     JTextField Jcourse_id = new JTextField(10);
     public JComponent dele(){          
         JPanel jp = new JPanel((new GridLayout(2, 1)));//����ʽ����   
         JPanel pp = new JPanel(new GridLayout(3, 1));
	     JPanel p1 = new JPanel();
	     JPanel p2 = new JPanel();         
         JPanel p3 = new JPanel();
         JButton del = new JButton("ɾ��");
         JButton renovate = new JButton("ˢ��");
         pp.add(p1);
         pp.add(p2);
         pp.add(p3);
         p2.add(tea_id);
         p2.add(Jtea_id);
         p2.add(del);
         p2.add(renovate);
         jp.add(pp);
         //��ʾ���н�ʦ��Ϣ�Թ�ɾ��         
         JScrollPane p = new JScrollPane(list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
         
         //ɾ����ť�ļ���
         del.addActionListener(new delListener());
         renovate.addActionListener(new ActionListener() {
        	 @Override
        	 public void actionPerformed(ActionEvent e) {
        		 sa2.each();
        	 }
         });
         jp.add(p);
         return jp;
         
     }
     
     //ɾ���γ�
     public JComponent course_dele(){ 
    	 
         JPanel jp = new JPanel((new GridLayout(2, 1)));//����ʽ����   
         JPanel pp = new JPanel(new GridLayout(3, 1));
	     JPanel p1 = new JPanel();
	     JPanel p2 = new JPanel();         
         JPanel p3 = new JPanel();
         JButton del2 = new JButton("ɾ��");
         JButton renovate = new JButton("ˢ��");
         pp.add(p1);
         pp.add(p2);
         pp.add(p3);
         p2.add(course_id);
         p2.add(Jcourse_id);
         p2.add(del2);
         p2.add(renovate);
         jp.add(pp);
         //��ʾ���н�ʦ��Ϣ�Թ�ɾ��         
         JScrollPane p = new JScrollPane(course_list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
         
         //ɾ����ť�ļ���
         del2.addActionListener(new del2Listener());
         renovate.addActionListener(new ActionListener() {
        	 @Override
        	 public void actionPerformed(ActionEvent e) {
        		 sa.course_each();
        	 }
         });
         jp.add(p);
         return jp;
         
     }
     
     //������
     public class delListener implements ActionListener{
	 		@Override
		 	public void actionPerformed(ActionEvent e) {
		 		//����ɾ������
	 			sa.del(Jtea_id.getText());
	 			//ˢ�½�ʦ�б�
	 			sa.each(); 			
		 	}	 			
	 }
     
     public class del2Listener implements ActionListener{
	 		@Override
		 	public void actionPerformed(ActionEvent e) {
		 		//����ɾ������
	 			sa.course_del(Jcourse_id.getText());
	 			//ˢ�½�ʦ�б�
	 			sa.course_each(); 			
		 	}	 			
	 }
     
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new delete();
	}

}
