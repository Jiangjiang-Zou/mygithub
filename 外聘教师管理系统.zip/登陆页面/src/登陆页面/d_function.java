package ��½ҳ��;

import java.awt.*;  
import javax.swing.*;
import java.sql.PreparedStatement;

import ��½ҳ��.Login.myListener1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class d_function {
	JPanel p;
	JButton add;
	//�����ı���
	JTextField jtfid = new JTextField(10);//��ʦ���
	JTextField jtftea_name = new JTextField(10);//����
	JTextField jtftea_sex = new JTextField(10);//�Ա�
	JPasswordField jpf1=new JPasswordField(10);//�����
	JPasswordField jpf2=new JPasswordField(10);//ȷ������
	JTextField jtfzhicheng = new JTextField(10);//ְ��
	JTextField jtfxueli = new JTextField(10);//ѧ��
	JTextField jtfco_name = new JTextField(10);//Ժϵ����
	JTextField course_id = new JTextField(10);//�γ̺�
	JTextField course_money = new JTextField(10);//���ν�
	JTextField course_name = new JTextField(10);//�γ���
	selectall sa = new selectall();
	JList<String> list = sa.course_each();//������пγ���Ϣ
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new homepage2("admin",2);
	}
	
	//�������ӿγ�ҳ��
	public JComponent course_register(){
		JScrollPane jsp = new JScrollPane(list,ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		GridLayout lay = new GridLayout(9,2);//����ʽ����  
		JButton submit2 = new JButton("�ύ") ;
		JButton resetting2 = new JButton("����");
		JPanel p = new JPanel(lay);
		JPanel jp = new JPanel(new GridLayout(2,1));
		JPanel p1 = new JPanel(),p2 = new JPanel(),p3 = new JPanel(),p4 = new JPanel(),p5 = new JPanel();
		JLabel JLid = new JLabel("�γ̺ţ�");
    	JLabel JLmoney = new JLabel("�ν�");
    	JLabel JLname = new JLabel("�γ�����");
    	p1.add(JLid);
    	p1.add(course_id);
    	p2.add(JLmoney);
    	p2.add(course_money);
    	p3.add(JLname);
    	p3.add(course_name);
    	
    	p4.add(submit2);
    	p4.add(resetting2);
    	
    	p.add(p5);
    	p.add(p1);
    	p.add(p2);
    	p.add(p3);
    	p.add(p4);
    	//p.add(jsp);
    	jp.add(p);
    	jp.add(jsp);
    	
    	//���Ӽ���
    	submit2.addActionListener(new submit2Listener());
    	resetting2.addActionListener(new resetting2Listener());
    	return jp;
	}
	
	//������
		 public class submit2Listener implements ActionListener{
		 		@Override
			 	public void actionPerformed(ActionEvent e) {
			 		//�����ύ�������ݿ⺯��	
		 			//��course_moneyת��Ϊdouble����
		 			double money = Double.parseDouble(course_money.getText());
		 			course_to_mySQL(course_id.getText(),money,course_name.getText());
		 			list = sa.course_each();
		 			
			 	}	 			
		 }
		 
	//���¿γ̱�
		 public void course_to_mySQL(String id,double money,String name) {
			 selectall sa = new selectall();
			 Connection conn = sa.con();
			 PreparedStatement pstmt = null;
			 try{
			    	// ִ�в�ѯ
			        System.out.println(" ʵ����Statement����...");
			        
			        //����ʦ��Ϣд�����ݿ�
			        String sql;
			        sql = "call Pro_addcourse(?,"+money+",?);";
			       
			       pstmt = conn.prepareStatement(sql);
			      
			       pstmt.setString(1,id);
			       pstmt.setString(2,name);
			       int n = pstmt.executeUpdate();		       
			        pstmt.close();
			        conn.close();
			    }catch(SQLException se){
			        // ���� JDBC ����
			        se.printStackTrace();
			    }catch(Exception e){
			        // ���� Class.forName ����
			        e.printStackTrace();
			    }finally{
			        // �ر���Դ
			        try{
			            if(pstmt!=null) pstmt.close();
			        }catch(SQLException se2){
			        }// ʲô������
			        try{
			            if(conn!=null) conn.close();
			        }catch(SQLException se){
			            se.printStackTrace();
			        }
			    }
			    System.out.println("Goodbye!");
			    JOptionPane.showMessageDialog(null,"���ӳɹ���","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
			    //return name;
		 }
		 
		 public class resetting2Listener implements ActionListener{
		 		@Override
			 	public void actionPerformed(ActionEvent e) {
			 		//�������ú���
		 			clear2(course_id,course_money,course_name);
			 	}	 			
		 }
		 
		 //���ú���
		 public void clear2(JTextField jtf1,JTextField jtf2,JTextField jtf3) {
			 String str = new String("");
			 jtf1.setText(str);
			 jtf2.setText(str);
			 jtf3.setText(str);
			
		 }
	
	
	//������ʦע��ҳ��
	public JComponent tea_register() {
		//���ַ�ʽ
    	GridLayout layout = new GridLayout(10,2);//����ʽ����   
        
        JButton submit = new JButton("�ύ") ;
    	JButton resetting = new JButton("����");
    	
        //�������
    	JPanel p = new JPanel(layout);

    	JPanel p1 = new JPanel(),p2 = new JPanel(),p3 = new JPanel(),
    			p4 = new JPanel(),p5 = new JPanel(),p6 = new JPanel(),
    			p7 = new JPanel(),p8 = new JPanel(),p9 = new JPanel(),
    			p10 = new JPanel();
    	//������ǩ
    	JLabel JLid = new JLabel("��ʦ��ţ�",SwingConstants.CENTER);
    	JLabel JLtea_name = new JLabel("��    ����");
    	JLabel JLsex = new JLabel("��    ��");

    	JLabel JLpassword1 = new JLabel("��    �룺");
    	JLabel JLpassword2 = new JLabel("ȷ�����룺");   	
    	JLabel JLzhicheng = new JLabel("ְ    �ƣ�");
    	JLabel JLxueli = new JLabel("ѧ    ����");    	
    	JLabel JLco_name = new JLabel("Ժϵ���ƣ�");    	
    	//���뵽���
    	p1.add(JLid);
    	p1.add(jtfid);
    	p2.add(JLtea_name);
    	p2.add(jtftea_name);
    	p3.add(JLsex);
    	p3.add(jtftea_sex);
    	p4.add(JLpassword1);
    	p4.add(jpf1);
    	p5.add(JLpassword2);
    	p5.add(jpf2);
    	p6.add(JLzhicheng);
    	p6.add(jtfzhicheng);
    	p7.add(JLxueli);
    	p7.add(jtfxueli);
    	p8.add(JLco_name);
    	p8.add(jtfco_name);
    	p9.add(submit);
    	p9.add(resetting);
    	
    	p.add(p1);
    	p.add(p2);
    	p.add(p3);
    	p.add(p4);
    	p.add(p5);
    	p.add(p6);
    	p.add(p7);
    	p.add(p8);
    	p.add(p9);
    	
    	//���Ӽ���
    	submit.addActionListener(new submitListener());
    	resetting.addActionListener(new resettingListener());
    	return p;
	}
	
	//������
	 public class submitListener implements ActionListener{
	 		@Override
		 	public void actionPerformed(ActionEvent e) {
		 		//�����ύ�������ݿ⺯��
	 			
			    //��֤�����Ƿ�һ��
	 			String str1 = new String(jpf1.getText());
	 			String str2 = new String(jpf2.getText());

	 			if(str1.equals(str2) != true){
		            JOptionPane.showMessageDialog(null,"���벻һ�£�\n����������","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);  
	 			}
	 			else
	 			tea_to_mySQL(jtfid,jtftea_name,str1,jtftea_sex,jtfzhicheng,jtfxueli,jtfco_name);
		 	}	 			
	 }
	 
	 //�ύ�������ݿ��ʦ��
	 public void tea_to_mySQL(JTextField jtf1,JTextField jtf2,String pwd,
			 JTextField jtf7 ,JTextField jtf3,JTextField jtf4,
			 JTextField jtf6) {
		 	selectall sa = new selectall();
		 	Connection conn = sa.con();
		 	PreparedStatement pstmt = null;
		    String str1 = new String(jtf1.getText());
		    String str2 = new String(jtf2.getText());
		    //String str3 = new String(jPf1.getText());
		    //String str4 = new String(jpf2.getText());
		    String str3 = new String(jtf7.getText());
		    String str4 = new String(jtf3.getText());
		    String str5 = new String(jtf4.getText());
		    //String str6 = new String(jtf5.getText());
		    String str7 = new String(jtf6.getText());
		    try{
		    	// ִ�в�ѯ
		        System.out.println(" ʵ����Statement����...");
		        
		        //����ʦ��Ϣд�����ݿ�
		        String sql;
		        sql = "call Pro_addinformation(?,?,?,?,?,?);";
		       // call Pro_addinformation('107','���ֽ�','��','����','��ʿ','205','���ù���ѧԺ');
		       pstmt = conn.prepareStatement(sql);
		       pstmt.setString(1,str1);
		       pstmt.setString(2,str2);//����
		       pstmt.setString(3,str3);
		       pstmt.setString(4,str4);
		       pstmt.setString(5,str5);
		       //pstmt.setString(6,str6);
		       pstmt.setString(6,str7);
		       int n = pstmt.executeUpdate();
		       
		       //����ʦid str2 ������ pwd д�����ݿ�
		       String sql2 = "insert into tea_user(name,password) values(?,?)";
		       pstmt.close();
		       PreparedStatement pstmt2 = conn.prepareStatement(sql2);
		       pstmt2.setString(1, str1);
		       pstmt2.setString(2, pwd);
		       int n2 = pstmt2.executeUpdate();
		        pstmt.close();
		        conn.close();
		    }catch(SQLException se){
		        // ���� JDBC ����
		        se.printStackTrace();
		    }catch(Exception e){
		        // ���� Class.forName ����
		        e.printStackTrace();
		    }finally{
		        // �ر���Դ
		        try{
		            if(pstmt!=null) pstmt.close();
		        }catch(SQLException se2){
		        }// ʲô������
		        try{
		            if(conn!=null) conn.close();
		        }catch(SQLException se){
		            se.printStackTrace();
		        }
		    }
		    System.out.println("Goodbye!");
		    JOptionPane.showMessageDialog(null,"ע��ɹ���","��ʾ��Ϣ",JOptionPane.WARNING_MESSAGE);
		    //return name;
	 }
	 
	 public class resettingListener implements ActionListener{
	 		@Override
		 	public void actionPerformed(ActionEvent e) {
		 		//�������ú���
	 			clear(jtfid,jtftea_name,jtftea_sex,jpf1,jpf2,jtfzhicheng,jtfxueli,jtfco_name);
		 	}	 			
	 }
	 
	 //���ú���
	 public void clear(JTextField jtf1,JTextField jtf2,JTextField jtf5,
			 JPasswordField jpf1,JPasswordField jpf2,
			 JTextField jtf3,JTextField jtf4,
			 JTextField jtf6) {
		 String str = new String("");
		 jtf1.setText(str);
		 jtf2.setText(str);
		 jtf3.setText(str);
		 jtf4.setText(str);
		 jtf5.setText(str);
		 jtf6.setText(str);
		 jpf1.setText(str);
		 jpf2.setText(str);
	 }
}
