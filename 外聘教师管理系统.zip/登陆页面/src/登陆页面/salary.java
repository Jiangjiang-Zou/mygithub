package ��½ҳ��;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import ��½ҳ��.homepage.salaryListener;

public class salary {
	private double tea_salary;//��ʦ���¹���
	JLabel j_salary;//��ʾ���¹���
	private String id;//�˺�
	JButton salary = new JButton("��ѯ���¹���");
	public salary(String name) {
		id = new String(name) ;
		j_salary = new JLabel("���¹��ʣ�");
	}
	public JComponent sal() {
		JPanel jp = new JPanel(new GridLayout(3, 1));
		JPanel p1 = new JPanel(),p2 = new JPanel();
		p2.add(salary);
		p2.add(j_salary);
		jp.add(p1);
		jp.add(p2);
		salary.addActionListener(new salaryListener());
		return jp;
	}
	
	//������
	 public class salaryListener implements ActionListener{
	 		@Override
	public void actionPerformed(ActionEvent e) {
		salary();
		j_salary.setText("���¹��ʣ�"+tea_salary);
	}	
}
	//���㵱�¹���
		 public void salary() {
			 	selectall sa = new selectall();
		    	Connection conn = sa.con();
		     	PreparedStatement pstmt = null;  	
		   	 try{	        
			        // ִ�в�ѯ
			        System.out.println(" ʵ����Statement����...");
			        
			        //����ʦ��Ϣд�����ݿ�
			        String sql;
			        sql = "call Pro_Salary(?);";
			       pstmt = conn.prepareStatement(sql);
			       pstmt.setString(1, id);
			       ResultSet rs = pstmt.executeQuery();
			       
			        // չ����������ݿ�
			        while(rs.next()){
			          tea_salary = rs.getDouble("����");
			        } 
			         //��ɺ�ر�
			        rs.close();
			        pstmt.close();
			        conn.close();
			    }catch(SQLException se){
			        // ���� JDBC ����
			        se.printStackTrace();
			    }catch(Exception e){
			        // ���� Class.forName ����
			        e.printStackTrace();
			    }finally{
			        // �ر���Դ
			        try{
			            if(pstmt!=null) pstmt.close();
			        }catch(SQLException se2){
			        }// ʲô������
			        try{
			            if(conn!=null) conn.close();
			        }catch(SQLException se){ 
			            se.printStackTrace();
			        }
			    }
			    System.out.println("Goodbye!");
		    
		 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
