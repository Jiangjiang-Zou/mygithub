package test;
import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;
public class Music {
	public static void playWav(String path, int seconds) {
		try {
			URL codebase = new URL("file:/"+path);
			AudioClip a = Applet.newAudioClip(codebase);
			a.play();
			Thread.sleep(seconds * 1000);
		}catch(Exception e) {
			System.out.println("ѽ��������");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Music.playWav("E:\\workspace\\��½ҳ��\\music\\music.wav", 5);
	}

}
